export default {
    /*
    "account": "configs/conf-account",
    "proxy": "configs/conf-example",
    "logging": "configs/conf-example",
    "inputs_01": "configs/conf-input_01",
    "inputs_02": "configs/conf-input_02"
    */
}
